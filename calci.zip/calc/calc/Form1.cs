﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calc
{
    public partial class Form1 : Form
    {
        Double res = 0;
        String op = "";
        bool isOp = false;
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
       
        private void button_Click(object sender, EventArgs e)
        {
            if ((result.Text == "0") || (isOp))
                result.Clear();
            isOp = false;
            Button button = sender  as Button;
            if (button.Text == ".")
            {
                if (!result.Text.Contains("."))
                    result.Text = result.Text + button.Text;

            }
            else
                result.Text = result.Text + button.Text;



           
        }
        private void op_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;

            if (res != 0)
            {
                equal.PerformClick();
                op = button.Text;
                labelCurOp.Text = res + " " + op;
                isOp = true;
            }
            else
            {

                op = button.Text;
                res = Double.Parse(result.Text);
                labelCurOp.Text = res + " " + op;
                isOp = true;
            }
        }
        private void equal_Click(object sender, EventArgs e)
        {
            switch (op)
            {
                case "+":
                    result.Text = (res + Double.Parse(result.Text)).ToString();
                    break;
                case "-":
                    result.Text = (res - Double.Parse(result.Text)).ToString();
                    break;
                case "x":
                    result.Text = (res * Double.Parse(result.Text)).ToString();
                    break;
                case "/":
                    result.Text = (res / Double.Parse(result.Text)).ToString();
                    break;
                default:
                    break;
            }
            res = Double.Parse(result.Text);
            labelCurOp.Text = "";
        }

        private void clr_Click(object sender, EventArgs e)
        {
            result.Text = "0";
            res = 0;
        }
        private void bck_Click(object sender, EventArgs e)
        {
            result.Text = "0";
            
        }
    }
}
