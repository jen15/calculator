﻿namespace calc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.one = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.sub = new System.Windows.Forms.Button();
            this.mul = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.clr = new System.Windows.Forms.Button();
            this.equal = new System.Windows.Forms.Button();
            this.div = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.TextBox();
            this.dot = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.labelCurOp = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // one
            // 
            this.one.Location = new System.Drawing.Point(74, 150);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(71, 55);
            this.one.TabIndex = 0;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.button_Click);
            // 
            // nine
            // 
            this.nine.Location = new System.Drawing.Point(283, 316);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(71, 55);
            this.nine.TabIndex = 1;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = true;
            this.nine.Click += new System.EventHandler(this.button_Click);
            // 
            // eight
            // 
            this.eight.Location = new System.Drawing.Point(177, 316);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(71, 55);
            this.eight.TabIndex = 2;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = true;
            this.eight.Click += new System.EventHandler(this.button_Click);
            // 
            // seven
            // 
            this.seven.Location = new System.Drawing.Point(74, 316);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(71, 55);
            this.seven.TabIndex = 3;
            this.seven.Tag = "button4";
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = true;
            this.seven.Click += new System.EventHandler(this.button_Click);
            // 
            // six
            // 
            this.six.Location = new System.Drawing.Point(274, 230);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(71, 55);
            this.six.TabIndex = 4;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = true;
            this.six.Click += new System.EventHandler(this.button_Click);
            // 
            // five
            // 
            this.five.Location = new System.Drawing.Point(177, 230);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(71, 55);
            this.five.TabIndex = 5;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.button_Click);
            // 
            // four
            // 
            this.four.Location = new System.Drawing.Point(74, 230);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(71, 55);
            this.four.TabIndex = 6;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.button_Click);
            // 
            // three
            // 
            this.three.Location = new System.Drawing.Point(274, 150);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(71, 55);
            this.three.TabIndex = 7;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.button_Click);
            // 
            // two
            // 
            this.two.Location = new System.Drawing.Point(177, 150);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(71, 55);
            this.two.TabIndex = 8;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.button_Click);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(383, 150);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(71, 55);
            this.add.TabIndex = 9;
            this.add.Text = "+";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.op_Click);
            // 
            // sub
            // 
            this.sub.Location = new System.Drawing.Point(383, 230);
            this.sub.Name = "sub";
            this.sub.Size = new System.Drawing.Size(71, 55);
            this.sub.TabIndex = 10;
            this.sub.Text = "-";
            this.sub.UseVisualStyleBackColor = true;
            this.sub.Click += new System.EventHandler(this.op_Click);
            // 
            // mul
            // 
            this.mul.Location = new System.Drawing.Point(383, 316);
            this.mul.Name = "mul";
            this.mul.Size = new System.Drawing.Size(71, 55);
            this.mul.TabIndex = 11;
            this.mul.Text = "x";
            this.mul.UseVisualStyleBackColor = true;
            this.mul.Click += new System.EventHandler(this.op_Click);
            // 
            // zero
            // 
            this.zero.Location = new System.Drawing.Point(177, 402);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(71, 55);
            this.zero.TabIndex = 12;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = true;
            this.zero.Click += new System.EventHandler(this.button_Click);
            // 
            // clr
            // 
            this.clr.Location = new System.Drawing.Point(507, 150);
            this.clr.Name = "clr";
            this.clr.Size = new System.Drawing.Size(71, 55);
            this.clr.TabIndex = 13;
            this.clr.Text = "CLR";
            this.clr.UseVisualStyleBackColor = true;
            this.clr.Click += new System.EventHandler(this.clr_Click);
            // 
            // equal
            // 
            this.equal.Location = new System.Drawing.Point(293, 402);
            this.equal.Name = "equal";
            this.equal.Size = new System.Drawing.Size(71, 55);
            this.equal.TabIndex = 14;
            this.equal.Text = "=";
            this.equal.UseVisualStyleBackColor = true;
            this.equal.Click += new System.EventHandler(this.equal_Click);
            // 
            // div
            // 
            this.div.Location = new System.Drawing.Point(383, 402);
            this.div.Name = "div";
            this.div.Size = new System.Drawing.Size(71, 55);
            this.div.TabIndex = 15;
            this.div.Text = "/";
            this.div.UseVisualStyleBackColor = true;
            this.div.Click += new System.EventHandler(this.op_Click);
            // 
            // result
            // 
            this.result.Location = new System.Drawing.Point(74, 99);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(380, 22);
            this.result.TabIndex = 16;
            // 
            // dot
            // 
            this.dot.Location = new System.Drawing.Point(74, 402);
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(71, 55);
            this.dot.TabIndex = 17;
            this.dot.Text = ".";
            this.dot.UseVisualStyleBackColor = true;
            this.dot.Click += new System.EventHandler(this.button_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(507, 230);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(71, 55);
            this.back.TabIndex = 19;
            this.back.Text = "back";
            this.back.UseVisualStyleBackColor = true;
            // 
            // labelCurOp
            // 
            this.labelCurOp.AutoSize = true;
            this.labelCurOp.Location = new System.Drawing.Point(71, 69);
            this.labelCurOp.Name = "labelCurOp";
            this.labelCurOp.Size = new System.Drawing.Size(0, 17);
            this.labelCurOp.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 498);
            this.Controls.Add(this.labelCurOp);
            this.Controls.Add(this.back);
            this.Controls.Add(this.dot);
            this.Controls.Add(this.result);
            this.Controls.Add(this.div);
            this.Controls.Add(this.equal);
            this.Controls.Add(this.clr);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.mul);
            this.Controls.Add(this.sub);
            this.Controls.Add(this.add);
            this.Controls.Add(this.two);
            this.Controls.Add(this.three);
            this.Controls.Add(this.four);
            this.Controls.Add(this.five);
            this.Controls.Add(this.six);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.one);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.op_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button sub;
        private System.Windows.Forms.Button mul;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button clr;
        private System.Windows.Forms.Button equal;
        private System.Windows.Forms.Button div;
        private System.Windows.Forms.TextBox result;
        private System.Windows.Forms.Button dot;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label labelCurOp;
    }
}

